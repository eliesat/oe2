# -*- coding: utf-8 -*-
from __future__ import print_function, unicode_literals
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Components.ConfigList import ConfigListScreen
from Components.config import ConfigText, ConfigSelection, ConfigYesNo
from Components.ActionMap import ActionMap
from Screens.MessageBox import MessageBox
from Components.Label import Label
import os
import sys
import io

CCCAM_VERSIONS = [
    "2.0.11", "2.1.1", "2.1.2", "2.1.3",
    "2.2.0", "2.2.1", "2.2.2",
    "2.3.0", "2.3.1", "2.3.2"
]

class EditServerScreen(Screen, ConfigListScreen):
    skin = """
<screen position="center,center" size="800,700" title="Enigma2 Reader Adder By: Ismail9875">
    <widget name="config" position="50,50" size="700,600" scrollbarMode="showOnDemand" font="Regular;40" itemHeight="50"  />
    <widget name="infoLabel" backgroundColor="#FF0016" position="200,10" size="500,40" font="Regular;35" halign="center" valign="center" cornerRadius="35" transparent="0"/>
    <ePixmap name="red" zposition="2" position="170,650" size="180,50" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Enigma2ReaderAdder/buttons/red.png" alphatest="blend" cornerRadius="25"/>
    <ePixmap name="green" zposition="2" position="360,650" size="180,50" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Enigma2ReaderAdder/buttons/green.png" alphatest="blend"/>
</screen>
    """

    def __init__(self, session, server_data=None):
        Screen.__init__(self, session)
        ConfigListScreen.__init__(self, [])

        self.server_data = server_data.copy() if server_data else self.get_default_data()
        
        # Initialize configuration elements
        self.label = ConfigText(default=self.server_data["label"])
        self.enable = ConfigSelection(choices=[("1", "Enabled"), ("0", "Disabled")], default=self.server_data["enable"])
        self.protocol = ConfigSelection(choices=[
            ("cccam", "CCcam"), 
            ("newcamd", "NewCamd"), 
            ("mgcamd", "MgCamd"), 
            ("cacheex", "CacheEx"), 
            ("internal", "Internal")
        ], default=self.server_data["protocol"])
        self.device = ConfigText(default=self.server_data["device"])
        self.user = ConfigText(default=self.server_data["user"])
        self.password = ConfigText(default=self.server_data["password"])
        self.group = ConfigSelection(choices=[(str(i), str(i)) for i in range(1, 65)], default=self.server_data["group"])
        self.cccversion = ConfigSelection(choices=CCCAM_VERSIONS, default=self.server_data["cccversion"])
        self.key = ConfigText(default=self.server_data["key"])
        self.keepalive = ConfigSelection(choices=[("1", "Enabled"), ("0", "Disabled")], default=self.server_data["keepalive"])
        self.caid = ConfigText(default=self.server_data["caid"])
        self.ident = ConfigText(default=self.server_data["ident"])
        self.chid = ConfigText(default=self.server_data["chid"])
        self.disablecrccws_only_for = ConfigText(default=self.server_data["disablecrccws_only_for"])
        self.advanced = ConfigYesNo(default=self.server_data["advanced"])

        # Add notifiers
        self.protocol.addNotifier(self.update_fields, initial_call=True)
        self.enable.addNotifier(self.update_fields, initial_call=False)
        self.advanced.addNotifier(self.update_fields, initial_call=False)

        self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
            "cancel": self.exit,
            "ok": self.open_keyboard,
            "green": self.save_config,
            "red": self.exit,
            "yellow": self.update,
            "blue": self.refresh,
        }, -1)

        self["infoLabel"] = Label("Press OK to edit selected field")
        self.create_setup()

    def get_default_data(self):
        """Return default configuration values"""
        return {
            "label": "server_name",
            "enable": "1",
            "protocol": "cccam",
            "device": "host,port",
            "user": "username",
            "password": "password",
            "group": "1",
            "cccversion": "2.0.11",
            "key": "0102030405060708091011121314",
            "caid": "",
            "ident": "",
            "chid": "",
            "keepalive": "1",
            "disablecrccws_only_for": "",
            "advanced": False
        }

    def reset_fields(self, result=None):
        """Reset all fields to default values"""
        default_data = self.get_default_data()
        for field in default_data:
            getattr(self, field).value = default_data[field]
        self.update_fields()
        self.create_setup()

    def update_fields(self, config_element=None):
        """Update UI based on current selections"""
        if self.protocol.value == "internal":
            self.device.value = "/dev/sci0"
        self.create_setup()

    def create_setup(self):
        """Build the configuration list"""
        self.list = [
            ("Server Label", self.label),
            ("Status", self.enable),
            ("Protocol", self.protocol),
            ("Host:Port", self.device),
            ("Username", self.user if self.enable.value == "1" else None),
            ("Password", self.password if self.enable.value == "1" else None),
            ("Group", self.group),
            ("CCcam Version", self.cccversion if self.protocol.value == "cccam" else None),
            ("Key", self.key if self.protocol.value in ["newcamd", "mgcamd"] else None),
            ("Advanced Options", self.advanced),
        ]

        if self.advanced.value or self.protocol.value == "internal":
            self.list += [
                ("CAID", self.caid),
                ("Ident", self.ident),
                ("CHID", self.chid),
                ("Keepalive", self.keepalive),
                ("Disable CRC Check For", self.disablecrccws_only_for)
            ]

        self["config"].list = [(name, config) for name, config in self.list if config is not None]
        self["config"].setList(self["config"].list)

    def open_keyboard(self):
        """Handle virtual keyboard input"""
        current = self["config"].getCurrent()
        if current:
            name, config = current
            if isinstance(config, ConfigText):
                self.session.openWithCallback(
                    self.keyboard_callback,
                    VirtualKeyBoard,
                    title="Enter {0}".format(name),
                    text=config.value
                )

    def keyboard_callback(self, text):
        """Process keyboard input"""
        if text:
            current_item = self["config"].getCurrent()
            if current_item:
                current_item[1].value = text

    def save_config(self):
        """Save configuration with smart filtering"""
        self.server_data.update({
            k: getattr(self, k).value for k in self.get_default_data().keys()
        })
        
        if self.save_to_file():
            self.session.openWithCallback(
                self.reset_fields,
                MessageBox,
                "Configuration saved successfully!",
                MessageBox.TYPE_INFO,
                timeout=3
            )
        else:
            self.session.open(
                MessageBox,
                "Failed to save configuration!",
                MessageBox.TYPE_ERROR
            )

    def generate_config_content(self):
        """Generate filtered configuration content"""
        fields = [
            # Mandatory fields
            ("label", "label = {0}".format(self.server_data['label']), True),
            ("enable", "enable = {0}".format(self.server_data['enable']), True),
            ("protocol", "protocol = {0}".format(self.server_data['protocol']), True),
            ("device", "device = {0}".format(self.server_data['device']), True),
            
            # Conditional fields
            ("user", "user = {0}".format(self.server_data['user']), 
             lambda: self.server_data['protocol'] != "internal" and self.server_data['user'] != "username"),
            
            ("password", "password = {0}".format(self.server_data['password']), 
             lambda: self.server_data['protocol'] != "internal" and self.server_data['password'] != "password"),
            
            ("group", "group = {0}".format(self.server_data['group']), 
             lambda: self.server_data['group'] != "1"),
            
            ("cccversion", "cccversion = {0}".format(self.server_data['cccversion']), 
             lambda: self.server_data['protocol'] == "cccam" and self.server_data['cccversion'] != "2.0.11"),
            
            ("key", "key = {0}".format(self.server_data['key']), 
             lambda: self.server_data['protocol'] in ["newcamd", "mgcamd"] and self.server_data['key'] != "0102030405060708091011121314"),
            
            ("caid", "caid = {0}".format(self.server_data['caid']), 
             lambda: bool(self.server_data['caid']) and (self.server_data['advanced'] or self.server_data['protocol'] == "internal")),
            
            ("ident", "ident = {0}".format(self.server_data['ident']), 
             lambda: bool(self.server_data['ident']) and self.server_data['advanced']),
            
            ("chid", "chid = {0}".format(self.server_data['chid']), 
             lambda: bool(self.server_data['chid']) and self.server_data['advanced']),
            
            ("keepalive", "keepalive = {0}".format(self.server_data['keepalive']), 
             lambda: self.server_data['keepalive'] != "1" and self.server_data['advanced']),
            
            ("disablecrccws_only_for", "disablecrccws_only_for = {0}".format(self.server_data['disablecrccws_only_for']), 
             lambda: bool(self.server_data['disablecrccws_only_for']) and self.server_data['advanced'])
        ]

        config_lines = ["[reader]"]
        for _, line, condition in fields:
            if isinstance(condition, bool) and condition:
                config_lines.append(line)
            elif callable(condition) and condition():
                config_lines.append(line)
        
        return config_lines

    def save_to_file(self):
        """Save configuration to files with proper formatting"""
        try:
            config_content = self.generate_config_content()
            if len(config_content) <= 1:
                return False
                
            formatted_content = "\n".join(config_content) + "\n\n"
            
            config_dir = "/etc/tuxbox/config"
            
            # Python 2/3 compatible directory creation
            try:
                os.makedirs(config_dir)
            except OSError as e:
                if e.errno != 17:  # File exists error
                    raise
            
            # Python 2/3 compatible file writing
            for filename in ["oscam.server", "ncam.server"]:
                file_path = os.path.join(config_dir, filename)
                with io.open(file_path, "a", encoding="utf-8") as f:
                    if os.path.getsize(file_path) > 0:
                        f.write(u"\n")
                    f.write(formatted_content)
            return True
            
        except Exception as e:
            print("Error saving configuration: {0}".format(str(e)))
            return False

    def exit(self):
        """Close the interface"""
        self.close()

    def update(self):
        """Placeholder for update functionality"""
        self.session.open(
            MessageBox,
            "Update service not available",
            MessageBox.TYPE_INFO,
            timeout=3
        )

    def refresh(self):
        """Placeholder for refresh functionality"""
        self.session.open(
            MessageBox,
            "Refresh service not available",
            MessageBox.TYPE_INFO,
            timeout=3
        )

def main(session, **kwargs):
    session.open(EditServerScreen)

def Plugins(**kwargs):
    return PluginDescriptor(
        name="Enigma2 Reader Adder",
        description="Advanced tools to add new reader to OSCam & NCam Emulators",
        icon="Enigma2ReaderAdder.png",
        where=PluginDescriptor.WHERE_PLUGINMENU,
        fnc=main
    )